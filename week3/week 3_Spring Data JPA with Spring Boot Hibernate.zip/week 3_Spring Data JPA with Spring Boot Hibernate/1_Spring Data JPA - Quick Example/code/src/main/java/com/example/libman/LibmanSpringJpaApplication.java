package com.example.libman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibmanSpringJpaApplication {
    public static void main(String[] args) {
        SpringApplication.run(LibmanSpringJpaApplication.class, args);
    }
}
