package com.example.hibernatequerydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateQueryDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(HibernateQueryDemoApplication.class, args);
    }
}
